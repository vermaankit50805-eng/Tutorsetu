# TutorSetu
A full-stack TutorSetu starter using Node.js, Express and SQLite.

## Run locally
1. Install Node.js 20+.
2. Open a terminal in this folder.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000` for parents and `http://localhost:3000/admin` for the admin panel.

## First admin login
If no admin exists, the app creates one from environment variables:
- `ADMIN_USERNAME` (default: `admin`)
- `ADMIN_PASSWORD` (default: `ChangeMe123!`)

For production, set strong values in your hosting provider's environment variables and set a strong `SESSION_SECRET`. Do not put passwords in frontend code.

## Production notes
Use HTTPS, persistent disk/database storage, a production-grade session store, regular backups, and restrict server access. SQLite is convenient for a small initial deployment; move to PostgreSQL if traffic grows.
